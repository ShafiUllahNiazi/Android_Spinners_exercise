package com.example.shafi.myapplicationb;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class VehicleListAtivity extends AppCompatActivity {
    ArrayList< Vehicle> vehicleArrayList;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private MyAdapter myAdapter;
    Button addvehicle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_list_ativity);
        addvehicle = findViewById(R.id.addvehicle);
        vehicleArrayList= new ArrayList<>();
        vehicleArrayList = getIntent().getParcelableArrayListExtra("vehicles_list");
        Toast.makeText(this, "vvvv "+vehicleArrayList.get(0).category, Toast.LENGTH_SHORT).show();

        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        myAdapter = new MyAdapter( vehicleArrayList);



        recyclerView.setAdapter(myAdapter);

        addvehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next_Screen();
            }
        });
    }

    private void next_Screen() {
        Intent intent = new Intent(this,AddItems.class);
        intent.putParcelableArrayListExtra("vehicles_list",  vehicleArrayList);

        startActivity(intent);
    }
}
