package com.example.shafi.myapplicationb;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AddItems extends AppCompatActivity {
    String[] list ;
    String[] list2;
    String[] list3;
    Button submit;
    ArrayList<Vehicle> vehicleArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);
        submit = findViewById(R.id.submitBtn);
        vehicleArrayList = new ArrayList<>();

        if(getIntent().getParcelableArrayListExtra("vehicles_list")==null){
            vehicleArrayList = new ArrayList<>();

        }
        else {
            vehicleArrayList = getIntent().getParcelableArrayListExtra("vehicles_list");
        }

        final Spinner category = findViewById(R.id.category);
        final Spinner model_year = findViewById(R.id.model);
        final Spinner type = findViewById(R.id.types);
        String[] items = new String[]{"1", "2"};
        list = new String[]{"11", "111", "1111"};
        list2 = new String[]{"22", "222", "2222"};
        list3 = new String[]{"2019", "2018", "2017"};


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        category.setAdapter(adapter);
        model_year.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, list3));

        final List<String> list_empty = new ArrayList<String>();

        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedClass = parent.getItemAtPosition(position).toString();
                switch (selectedClass)
                {
                    case "1":

                        type.setAdapter(new ArrayAdapter<String>(AddItems.this,
                                android.R.layout.simple_spinner_dropdown_item,list
                               ));
                        break;

                    case "2":
                        type.setAdapter(new ArrayAdapter<String>(AddItems.this,
                                android.R.layout.simple_spinner_dropdown_item,
                                list2));
                        break;
                    default:
                        type.setAdapter(new ArrayAdapter<String>(AddItems.this,
                                android.R.layout.simple_spinner_dropdown_item,
                                list_empty));


                }



            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Vehicle vehicle = new Vehicle(category.getSelectedItem().toString(),
                        type.getSelectedItem().toString(),
                        model_year.getSelectedItem().toString()) ;

                vehicleArrayList.add(vehicle);

                goNext();
            }
        });
    }

    private void goNext() {
        Intent intent = new Intent(this,VehicleListAtivity.class);
        intent.putParcelableArrayListExtra("vehicles_list",  vehicleArrayList);

        startActivity(intent);
    }
}
