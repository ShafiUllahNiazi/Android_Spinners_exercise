package com.example.shafi.myapplicationb;

import android.os.Parcel;
import android.os.Parcelable;

public class Vehicle implements Parcelable {
    String category, type, year;

    public Vehicle(String category, String type, String year) {
        this.category = category;
        this.type = type;
        this.year = year;
    }

    protected Vehicle(Parcel in) {
        category = in.readString();
        type = in.readString();
        year = in.readString();
    }

    public static final Creator<Vehicle> CREATOR = new Creator<Vehicle>() {
        @Override
        public Vehicle createFromParcel(Parcel in) {
            return new Vehicle(in);
        }

        @Override
        public Vehicle[] newArray(int size) {
            return new Vehicle[size];
        }
    };

    public String getCategory() {
        return category;
    }

    public String getType() {
        return type;
    }

    public String getYear() {
        return year;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(category);
        dest.writeString(type);
        dest.writeString(year);
    }
}
